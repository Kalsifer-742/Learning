<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div id="root">
    <img src="https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fkeybiscayne.fl.gov%2Fclientuploads%2FParksRecreation%2FJPEGS-PDFs%2FLimeBikeLogo.jpg&f=1&nofb=1" alt="Logo" id="logo">
        <form method="post" action="auth.php">
            <div id="username">
                <label>Username</label>
                <input type="text" name="user">
            </div>
            <div id="password">
                <label>Password</label>
                <input type="text" name="password">
            </div>
            <div id="button">
                <input type="submit" value="Accedi" id="submit">
            </div>
        </form>
    </div>
</body>

</html>
