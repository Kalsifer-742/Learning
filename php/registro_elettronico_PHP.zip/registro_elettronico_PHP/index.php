<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="style.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.7.4/lottie.min.js" integrity="sha512-m0RQU4SBx0p/bLwRiI4fJBGRafVLZ4s86wRe1+OAx5EXbcWiS/X1jvYdJQRD8jOoIVl+WTyVeMawUWVCh1O8+Q==" crossorigin="anonymous"></script>
</head>
<body>
    <p id="title">Home</p>

    <form method="get" action="registro.php">
        <label for="classes">Scegli una classe:</label>
        <select name="classes" id="classes">
            <?php
                $handle = fopen("users.csv", "r");
                
                while ( ($data = fgetcsv($handle, 1000, ";") ) !== FALSE ) 
                {
                    echo "<option value=$data[0]>$data[0]</option>";
                }   

                fclose($handle);
            ?>
        </select>
        <input type="submit" number="submit" value="Submit" id="idx_input">
    </form>
    <div id="animation"></div>
</body>
<script>
    var animation = bodymovin.loadAnimation({
    container: document.getElementById('animation'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'school.json',
    rendererSettings: {
        preserveAspectRatio: 'xMinYMin slice', // Supports the same options as the svg element's preserveAspectRatio property
    }
})
</script>

</html>