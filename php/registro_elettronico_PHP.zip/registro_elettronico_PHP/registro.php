<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Elettronico</title>

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <p id="title">Registro Elettronico</p>

    <form method="post">
    <?php
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            $student = $_GET['students'];
            $vote = $_GET['vote'];
            $comment = $_GET['comment'];

            $lines = array( //future proof
                array($student, $vote, $comment),
            );

            $h = fopen("votes.csv", "a");
            foreach ($lines as $line) {
                fputcsv($h, $line);
            }
        }
    ?>
    <label for="students">Scegli uno studente:</label>
    <select name="students" id="students">
    <?php
        $class = $_GET["classes"];
        $handle = fopen("users.csv", "r");
        
        while ( ($data = fgetcsv($handle, 1000, ";") ) !== FALSE ) 
        {   
            if($class == $data[0])
                echo "<option value=$data[1]"."_"."$data[2]>$data[1] $data[2]</option>";
        }   

        fclose($handle);
    ?>
    </select>
    <select name="vote" id="vote">
    <?php
        for($i = 1; $i < 11; $i++)
        {
            echo "<option value=$i>$i</option>";
        }
    ?>
    </select>
    <br>
    <textarea id="comment" name="comment" placeholder="Commento ..." maxlength="256"></textarea>
    <br>
        <input type="submit" number="submit" value="Submit">
    </form>
    <br>
</body>
</html>