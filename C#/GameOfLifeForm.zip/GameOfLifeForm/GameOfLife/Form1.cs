﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameOfLife
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        static int bufferRefreshInterval = 1;
        static int grid_size = 10;
        int[,] grid = new int[grid_size, grid_size];
        int[,] next = new int[grid_size, grid_size];
        SolidBrush brush = new SolidBrush(Color.Black);

        private void Form1_Load(object sender, EventArgs e)
        {
            Timer bufferRefresh = new Timer();
            bufferRefresh.Tick += new EventHandler(bufferRefresh_Tick);
            bufferRefresh.Interval = bufferRefreshInterval;
            bufferRefresh.Enabled = true;
            bufferRefresh.Start();

            PopulateGrid();
        }

        void bufferRefresh_Tick(object sender, EventArgs e)
        {
            this.Refresh();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            for (int i = 0; i < grid_size; i++)
            {
                for (int j = 0; j < grid_size; j++)
                {
                    if (grid[i, j] == 1)
                    {
                        e.Graphics.FillRectangle(brush, i * 10, j * 10, 10, 10);
                    }
                }
            }

            CalcNext();

            grid = next;
        }

        void PopulateGrid()
        {
            Random r = new Random();

            for (int i = 0; i < grid_size; i++)
            {
                for (int j = 0; j < grid_size; j++)
                {
                    grid[i,j] = r.Next(2);
                }
            }
        }

        void CalcNext()
        {
            int near = 0;
            for(int i = 0; i < grid_size; i++)
            {
                for (int j = 0; j < grid_size; j++)
                {
                    near = CalcNear(i, j);
                    if (grid[i,j] == 0 && near == 3)
                    {
                        next[i, j] = 1;
                    }
                    else if(grid[i, j] == 1 && (near < 2 || near > 3))
                    {
                        next[i, j] = 0;
                    }
                    else
                    {
                        next[i, j] = grid[i, j];
                    }
                }
            }
        }

        int CalcNear(int x, int y)
        {
            int sum = 0;

            for (int i = -1; i < 2; i++)
            {
                for (int j = -1; j < 2; j++)
                {
                    try
                    {
                        sum += grid[x + i , y + j];
                    }
                    catch(IndexOutOfRangeException)
                    {
                        //fai niente
                    }
                }
            }

            sum -= grid[x, y];

            return sum;
        }
    }
}
