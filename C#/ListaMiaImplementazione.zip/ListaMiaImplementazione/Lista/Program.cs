﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista
{
    public interface MyList<T>
    {
        void Add(T data);
        void Add(int index, T data);
        void Remove(int index);
        void Clear();
        T Get(int index);
        bool isEmpty();
        int Size();
    }

    class Node<T>
    {
        public T data;
        public Node<T> next;

        public Node()
        {
            this.next = null;
        }

        public Node(T data)
        {
            this.data = data;
            this.next = null;
        }

        public Node(T data, Node<T> next)
        {
            this.data = data;
            this.next = next;
        }

    }

    class SingleLinkedList<T> : MyList<T>
    {
        private Node<T> head;

        public SingleLinkedList()
        {
            this.head = null;
        }

        private Node<T> GetLastNode()
        {
            Node<T> tmp = this.head;
            while (tmp.next != null)
            {
                tmp = tmp.next;
            }
            return tmp;
        }

        public void Add(T data)
        {
            Node<T> tmp = new Node<T>(data);
            if (head != null)
            {
                Node<T> end = GetLastNode();
                end.next = tmp;
                tmp.next = null;
            }
            else
            {
                this.head = tmp;
            }
        }

        public void Add(int index, T data)
        {
            Node<T> _new = new Node<T>(data);
            Node<T> tmp = this.head;

            if (index >= 0 && index < this.Size())
            {
                for (int i = 0; i < index - 1; i++)
                {
                    tmp = tmp.next;
                }
                _new.next = tmp.next;
                tmp.next = _new;
            }
            else
            {
                throw new IndexOutOfRangeException("Indice negativo o superiore alla grandezza della lista");
            }
        }

        public void Remove(int index)
        {
            Node<T> tmp = this.head;

            if (index >= 0 && index < this.Size())
            {
                if (index != 0)
                {
                    for (int i = 0; i < index - 1; i++)
                    {
                        tmp = tmp.next;
                    }
                    Node<T> del;
                    del = tmp.next;
                    tmp.next = del.next;
                    del.next = null;
                    //tmp.next = tmp.next.next;
                }
                else
                {
                    this.head = tmp.next;
                }
            }
            else
            {
                throw new IndexOutOfRangeException("Indice negativo o superiore alla grandezza della lista");
            }
        }

        public void Clear()
        {
            Node<T> tmp = this.head;

            while (tmp.next != null)
            {
                this.head = tmp.next;
                tmp.next = null;
                tmp = this.head;
            }

            //perché tmp = null ?

            this.head = null;
        }

        public T Get(int index)
        {
            Node<T> tmp = this.head;

            if (index >= 0 && index < this.Size())
            {
                for (int i = 0; i < index; i++)
                {
                    tmp = tmp.next;
                }
            }
            else
            {
                throw new IndexOutOfRangeException("Indice negativo o superiore alla grandezza della lista");
            }
            return tmp.data;
        }

        public bool isEmpty()
        {
            return (this.head == null);
        }

        public int Size()
        {
            Node<T> tmp = this.head;
            int c = 0;

            while (tmp != null)
            {
                tmp = tmp.next;
                c++;
            }

            return c;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            SingleLinkedList<string> lista = new SingleLinkedList<string>();
            lista.Add("Ciao");
            lista.Add("Come");
            lista.Add("Va");
            lista.Add("?");

            lista.Add(2, "INTRUSO");
            //lista.Add(5 ,"INTRUSO"); test eccezzione

            lista.Remove(4);
            //lista.Remove(5); test eccezzione

            if(Console.Read() == 'C')
            {
                lista.Clear();
            }                

            for (int i = 0; i < lista.Size(); i++)
            {
                Console.WriteLine(lista.Get(i));
            }
            //Console.WriteLine(lista.Get(4)); test eccezzione

            Console.WriteLine(lista.isEmpty());

            Console.ReadKey();
        }
    }
}
