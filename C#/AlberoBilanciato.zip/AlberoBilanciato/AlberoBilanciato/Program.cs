﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlberoBilanciato
{
    class Program
    {
        class Libro
        {
            public int codice;

            public Libro() { codice = 0; }
            public Libro(int n) { codice = n; }
        }

        class Biblioteca
        {
            Libro[] inventario;

            public Biblioteca() { inventario = null; }
            public Biblioteca(int len) { inventario = new Libro[len]; }

            public Libro[] Inventario { get { return inventario; } }

            public void Popola()
            {
                Random rnd = new Random();
                for (int i = 0; i < inventario.Length; i++)
                {
                    inventario[i] = new Libro(rnd.Next(0, 10));
                }
            }

            public void Ordina()
            {
                if(inventario[0] != null)
                {
                    int[] tmp = new int[inventario.Length];
                    for (int i = 0; i < inventario.Length; i++)
                    {
                        tmp[i] = inventario[i].codice;
                    }
                    Ordinamento.QuickSort(tmp, 0, tmp.Length - 1);
                    for (int i = 0; i < inventario.Length; i++)
                    {
                        inventario[i].codice = tmp[i];
                    }
                }
                else
                {
                    Console.WriteLine("ERRORE >>> impossibile ordinare, la biblioteca é vuota");
                }
            }

            public void Stampa()
            {
                foreach (var libro in inventario)
                {
                    Console.WriteLine("Codice: " + libro.codice);
                }
            }
        }

        static class Ordinamento
        {
            public static int Partition(int[] arr, int low, int high)
            {
                int pivot = arr[high];
                int i = (low - 1);
                int temp;
                for (int j = low; j < high; j++)
                {
                    if (arr[j] <= pivot)
                    {
                        i++;
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
                temp = arr[i + 1];
                arr[i + 1] = arr[high];
                arr[high] = temp;
                return (i + 1);
            }

            public static void QuickSort(int[] arr, int low, int high)
            {
                if (low < high)
                {
                    int p = Partition(arr, low, high);
                    QuickSort(arr, low, p - 1);
                    QuickSort(arr, p + 1, high);
                }
            }
        }

        static class Conversione
        {
            public static int[] ConvertToint(Libro[] arr)
            {
                int[] tmp = new int[arr.Length];
                for (int i = 0; i < arr.Length; i++)
                {
                    tmp[i] = arr[i].codice;
                }
                return tmp;
            }
        }
        
        class Nodo
        {
            public Nodo left;
            public Nodo right;
            public int value;

            public Nodo() { left = null; right = null; }
            public Nodo(int v) { left = null; right = null; value = v; }
            public Nodo(Nodo l, Nodo r, int v) { left = l; right = r; value = v; }
        }

        
        class Albero
        {
            Nodo root;
            int figli;

            public Albero() { root = null; }
            public Albero(int[] items) 
            {
                root = new Nodo(items[items.Length / 2]);
                foreach (var item in items)
                {
                    if (item != root.value)
                    {
                        Add(root, item);
                    }
                }
            }

            /*public void Crea(int[] items)
            {
                root = new Nodo(items[items.Length / 2]);
                foreach (var item in items)
                {
                    if (item != root.value)
                    {
                        Add(root, item);
                    }
                }
            }*/

            private void Conta(Nodo root)
            {
                if (root == null) 
                    return;
                this.figli++;
                Conta(root.left); 
                Conta(root.right);
            }

            private void Add(Nodo root, int n)
            {
                if (root.left == null)
                {
                    root.left = new Nodo(n);
                    return;
                }
                else if (root.right == null)
                {
                    root.right = new Nodo(n);
                    return;
                }

                this.figli = 0;
                Conta(root.left);
                int nl = this.figli;
                this.figli = 0;
                Conta(root.right);
                int nr = this.figli;
                if (nl <= nr)
                {
                    Add(root.left, n);
                }
                else
                {
                    Add(root.right, n);
                }
            }
        }

        static void Main(string[] args)
        {
            Biblioteca bertoliana = new Biblioteca(5);
            bertoliana.Popola();
            bertoliana.Ordina();
            bertoliana.Stampa();

            /*Albero bilanciato = new Albero();
            bilanciato.Crea(ConvertToint(bertoliana.Inventario));*/

            Albero bilanciato = new Albero(Conversione.ConvertToint(bertoliana.Inventario));

            //si puó vedere l'albero formato dal debugger

            Console.ReadKey();
        }
    }
}
