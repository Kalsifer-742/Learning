import random
import colors

class Bomb:
    __slots__ = ["wires", "serial", "tocut"]
    def __init__(self):
        import string
        self.wires = [colors.randomColor() for _ in range(random.randint(3, 5))] 
        self.serial = random.randint(0, 9)
        iseven = not bool(self.serial%2)
        def lastwire(color):
            return list(reversed(self.wires)).index(color)
        def onlyone(color):
            return self.wires.index(color) == lastwire(color)
        if len(self.wires) == 3:
            if colors.red not in self.wires:
                self.tocut = 1
            elif self.wires[2] == colors.white:
                self.tocut = 2
            elif colors.blue in self.wires and not onlyone(colors.blue):
                self.tocut = lastwire(colors.blue)
            else:
                self.tocut = 2
        elif len(self.wires) == 4:
            if iseven and colors.red in self.wires and not onlyone(colors.red):
                self.tocut = lastwire(colors.red)
            elif (self.wires[3] == colors.yellow and colors.red not in self.wires) or (colors.blue in self.wires and onlyone(colors.blue)):
                self.tocut = 0
            elif colors.yellow in self.wires and onlyone(colors.yellow):
                self.tocut = 3
            else:
                self.tocut = 1
        elif len(self.wires) == 5:
            if self.wires[4] == colors.black and not iseven:
                self.tocut = 3
            elif colors.red in self.wires and onlyone(colors.red) and colors.yellow in self.wires and not onlyone(colors.yellow):
                self.tocut = 0
            elif colors.black not in self.wires:
                self.tocut = 1
            else:
                self.tocut = 0
        #elif len(self.wires) == 6:
        #    if colors.yellow not in self.wires and not iseven:
        #        self.tocut = 2
        #    elif colors.yellow in self.wires and onlyone(colors.yellow) and colors.white in self.wires and not onlyone(colors.white):
        #        self.tocut = 3
        #    elif colors.red not in self.wires:
        #        self.tocut = 5
        #    else:
        #        self.tocut = 3
