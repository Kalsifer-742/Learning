#!/bin/env python3
from bomb import Bomb
from serial import Serial
from serial.tools import list_ports as listports
import struct
import random
import string

def toByte(obj):
    assert obj < 256, ValueError("Number too Big")
    return struct.pack("B", obj)

while input("Scrivi E e Invio, qualsiasi altra cosa per cominciare") != "E":
    try:
        serdev = listports.grep("ttyACM").__next__()
    except StopIteration:
        print("Arduino not connected")
        continue
    bomb = Bomb()
    with Serial(serdev.device, timeout=5) as adn:
        def flush():
            adn.flush()
            while adn.read_until(terminator=b"\r\n") != b"ack\r\n":
                pass
            
        if adn.read_until(terminator=b"\r\n") != b"ready\r\n":
            print("Couln't receive the \"ready\" message")
            continue
        adn.timeout = None
        adn.write(toByte(len(bomb.wires)))
        flush()
        for wire in bomb.wires:
            print(wire)
            adn.write(toByte(wire.r))
            adn.write(toByte(wire.g))
            adn.write(toByte(wire.b))
            flush()
        print("Everything has been sent\n")
        print("Serial Number: {}{}".format(
            "".join([random.choice(string.ascii_uppercase+string.digits) for _ in range(5)]),
            bomb.serial
        ))
        errors = []
        adn.flush()
        while True:
            wire = struct.unpack("B", adn.read())[0]
            print(wire)
            if wire in errors:
                print("ok")
                adn.write("ok".encode("ascii"))
            elif wire != bomb.tocut:
                print("miscut")
                adn.write("miscut".encode("ascii"))
                errors.append(wire)
                print("Hai fatto {} error{}".format(len(errors), "i" if len(errors) > 1 else "e"))
                if(len(errors) > 3):
                    print("Hai perso")
            elif wire == bomb.tocut:
                print("won")
                adn.write("won".encode("ascii"))
                print("Sei un grande bruh che momento bruh")
                break
            
