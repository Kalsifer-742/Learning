class Color:
    r = 0
    g = 0
    b = 0
    def __init__(self, red, green, blue):
        self.r = red
        self.g = green
        self.b = blue
    def __str__(self):
        return "Color ({},{},{})".format(self.r, self.g, self.b)

def makestr(col):
    def str(self):
        return col
    return str

red = Color(255, 0, 0)
red.__str__ = makestr("Red")
blue = Color(0, 0, 255)
blue.__str__ = makestr("Blue")
white = Color(255, 255, 255)
white.__str__ = makestr("White")
black = Color(0, 0, 0)
black.__str__ = makestr("Black")
yellow = Color(255, 255, 0)
yellow.__str__ = makestr("Yellow")

def randomColor():
    import random
    return random.choice([red, blue, white, black, yellow])
