#%%
from common import rdln

class Portal:
    def __init__(self, inx, iny, outx, outy):
        self.x = int(inx)
        self.y = int(iny)
        self.outx = int(outx)
        self.outy = int(outy)

def distance(qx, qy, portx, porty):
    return abs(portx - qx)  + abs(porty - qy)

from sys import argv as args
infile = open(args[1])
outfile = open("quantout.txt", "w")
for t in range(1, int(rdln(infile))+1):
    print(t)
    traveled = 0
    rdln(infile)
    qbitcoord = rdln(infile).split(" ") 
    qy = int(qbitcoord[1])
    qx = int(qbitcoord[0])
    portalList = []
    portn = int(rdln(infile))
    for portal in range(portn):
        portalcoord = rdln(infile).split(" ")
        portalList.append(Portal(int(portalcoord[0]), int(portalcoord[1]), int(portalcoord[2]), int(portalcoord[3])))
    from copy import deepcopy
    remainingPortals = deepcopy(portalList)
    for portal in portalList:
        distanceList = {}
        for port in remainingPortals:
            distanceList[port] = distance(qx, qy, port.x, port.y)
        traveled += min(distanceList.values()) % 100003
        newq = None
        for port, val in distanceList.items():
            if val == min(distanceList.values()):
                newq=port
                break
        qx = newq.outx
        qy = newq.outy
        remainingPortals.remove(newq)
    outfile.write("Case #{}: {}\n".format(t, traveled))
infile.close()
outfile.close()
