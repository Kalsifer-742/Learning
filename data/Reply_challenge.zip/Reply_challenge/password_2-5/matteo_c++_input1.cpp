#include <fstream>
#include <iostream>
#include <sstream>
#include <cmath>
#include <bitset>

int main()
{
    std::ifstream fi("input");
    std::ofstream fo("output");
    int t;
    fi >> t;
    for(int i = 0; i < t; i++)
    {
        int a, b, res = 0;
        std::string c;
        fi >> a >> b >> c;

        if(a <= b)
            res = pow(2,a)-(a==b?1:0);
        else
            for(unsigned char i = 0; i < pow(2, a); ++i)
            {
                std::bitset<3> bs(i);
                std::stringstream ss("");
                ss << bs;
                if(ss.str().find(c) == std::string::npos)
                    res++;
            }
        fo << "Case #" << i+1 << ": " << res << "\n";
    }
}