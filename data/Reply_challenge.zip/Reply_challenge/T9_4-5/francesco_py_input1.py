#%%
keyboard = {
    2: "ABC",
    3: "DEF",
    4: "GHI",
    5: "JKL",
    6: "MNO",
    7: "PQRS",
    8: "TUV",
    9: "WXYZ"
}

from common import rdln
from sys import argv as args
infile = open(args[1])
outfile = open("t9out.txt", "w")
for t in range(1, int(rdln(infile))+1):
    print(t)
    difford = int(rdln(infile).split(" ")[1])-1
    pointgrid = {}
    for fc in range(26):
        letter = chr(65+fc)
        pointgrid[letter] = {}
        for lc, lv in enumerate(rdln(infile).split(" ")):
            pointgrid[letter][chr(65+lc)] = int(lv)
    possiblePass = {}
    buttPressd = rdln(infile)
    for c1 in keyboard[int(buttPressd[0])]:
        for c2 in keyboard[int(buttPressd[1])]:
            for c3 in keyboard[int(buttPressd[2])]:
                possiblePass[c1+c2+c3] = pointgrid[c1][c2]+pointgrid[c2][c3]
    outfile.write("Case #{}: {}\n".format(t, sorted(possiblePass, key = lambda x: possiblePass[x], reverse = True)[difford]))
infile.close()
outfile.close()    
