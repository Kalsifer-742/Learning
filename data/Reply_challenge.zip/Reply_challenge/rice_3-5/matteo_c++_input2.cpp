#include <fstream>
#include <iostream>
#include <cmath>

int main(int argc, char** argv)
{
    long double t;
    std::ifstream fi(argv[1]);
    std::ofstream fo(argv[2]);

    fi >> t;

    for(long double i = 0; i < t; ++i)
    {
        long double r,n,m;
        fi >> r >> n >> m;
        long double grains = 0, cell = 1;

        for(long double j = 1; j < n * n; ++j)
        {
            cell *= r;
            cell = std::fmod(cell, m);
            grains += cell;
            grains = std::fmod(grains, m);
        }

        fo << "Case #" << i+1 << ": " << std::fmod(grains,m) << "\n";
    }
}