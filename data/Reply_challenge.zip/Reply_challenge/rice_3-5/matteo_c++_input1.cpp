#include <fstream>
#include <cstdint>


int main(int argc, char** argv)
{
    int t;
    std::ifstream fi(argv[1]);
    std::ofstream fo(argv[2]);

    fi>>t;

    for(int i = 0; i < t; ++i)
    {
        uint32_t r,n,m;
        uint64_t grains = 1;
        fi >> r >> n >> m;

        uint64_t cell = 1;

        for(uint64_t j = 1; j < n * n; ++j)
        {
            cell   *= r;
            grains += cell;
        }

        fo << "Case #" << i << ": " << grains % m << "\n";
    }
}