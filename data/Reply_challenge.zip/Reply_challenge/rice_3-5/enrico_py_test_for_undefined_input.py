t = 1
i = 0

while i < t:
    grains = 1
    cell = 1
    r = 2
    n = 170
    m = 149
    j = 0
    while j < n*n:
        cell *= r
        grains += cell

    print(grains)
    
