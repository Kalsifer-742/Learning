/*!
    \file zoo.cpp
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

#include "header.h"

using namespace std;

//! \return void \fn Zoo
Zoo::Zoo(){}

//! \return void \fn Zoo \param[in] animali e' la lista di animali \param[in] custodi e' la lista dei custodi
Zoo::Zoo(Animale* animali, Custode* custodi)
{
    this->animali = animali;
    this->custodi = custodi;
}

