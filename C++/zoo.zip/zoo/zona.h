/*!
    \file zona.h
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

using namespace std;

//! \class Zona
class Zona{
    public:
        Zona();
        Zona(string nome);
        string GetNome();
    private:
        string nome; //! \property nome
};
