/*!
    \file animale.h
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

using namespace std;

//! \class Animale
class Animale {
    public:
        Animale();
        Animale(Zona zona);
        void Nasce();
        void Mangia();
        void EmetteVerso();
        void CambiaZona(Zona zona);
        void Morte();
    private:
        Zona zona; //! \property zona
        static int nato; //! \property nato
};
