/*!
    \file zona.cpp
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

#include "header.h"

using namespace std;

//! \return void \fn Zona
Zona::Zona()
{
    nome = "";
}

//! \return void \fn Zona
Zona::Zona(string n){
    nome = n;
}

//! \return string \fn GetNome
string Zona::GetNome(){
        return nome;
}
