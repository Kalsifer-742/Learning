/*!
    \file main.cpp
	\author Edoardo Bertollo, azad_fardin
	\date 15/01/2020
    \versione 1.0.1
	
	\todo finire di implementare il main
*/

#include "header.h"

using namespace std;

int main()
{
	int scelta, scelta_custode, scelta_animale;
	string zona, tipo_animale;
	
	cout << "MENU' " << endl << "1. Custode" << endl << "2. Animale" <<endl << "3. Uscita" <<endl ;
	cin >> scelta;
	switch (scelta)
	{
		case 1:
			cout << "1. Assunzione" << endl << "2. Pulisci" << endl << "3. Porta Pappe" << endl << "4. Conta Animali" << endl; 
			cin >> scelta_custode;
			switch (scelta_custode)
			{
			case 1:
				cout << "Zona: ";
				cin >> zona;
				
				break;
			case 2:
				
				break;
			case 3:
				break;
			case 4:
				break;
			default:
				cout << "Valore inserito non valido." << endl;
				break;
			}
			break;
			
		case 2:
			cout << "Inserisci tipo animale: ";
			cin >> tipo_animale;
			cout << "1. Nascita" << endl << "2. Mangia" << endl << "3. Emette un verso" << endl << "4. Sposta" << "5. Muore" << endl;
			cin >> scelta_animale;
			//switch ()
			break;
		case 3:
			break;
		default:
			cout << "Valore inserito non valido." << endl;
			break;
	}
    return 0;
}
