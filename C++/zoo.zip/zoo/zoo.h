/*!
    \file zoo.h
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

using namespace std;

//! \class Zoo
class Zoo {
    public:
        Zoo();
        Zoo(Animale* animali, Custode* custodi);
    private:
        Animale* animali; //! \property animali
        Custode* custodi; //! \property custodi
};