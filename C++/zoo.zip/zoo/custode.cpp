/*!
    \file custode.cpp
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

#include "header.h"

using namespace std;

//! \note inizializzazione variabile statica "assunto"
int Custode::assunto = 0;

//! \return void \fn Custode
Custode::Custode() {}
//! \return void \fn Custode \param[in] z identifica la zona assegnata al custode
Custode::Custode(Zona z) {
        zona = z;
        assunto++;
    }

//! \return void \fn Pulisce
void Custode::Pulisce() {
        cout << "pulito\n";
    }

//! \return void \fn PortaCibo
void Custode::PortaCibo() {
        cout << "cibo portato\n";
    }

//! \return void \fn ContaAnimali
void Custode::ContaAnimali() {
        cout << "animali contati: " << assunto << "\n";
    }
