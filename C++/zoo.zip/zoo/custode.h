/*!
    \file custode.h
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

using namespace std;

//! \class Custode
class Custode {
    public:
        Custode();
        Custode(Zona zona); 
        void Pulisce();    
        void PortaCibo();
        void ContaAnimali();         
    private:
        Zona zona; //! \property zona
        static int assunto; //! \property assunto
};