/*!
    \file animale.cpp
	\author enrico_dalla_croce, andrea_ervetti
	\date 08/01/2020
    \versione 1.0.1
*/

#pragma once

#include "header.h"

using namespace std;

//! \note inizializzazione variabile statica "nato"
int Animale::nato = 0;

//! \return void \fn Animale
Animale::Animale() {}
//! \return void \fn Animale \param[in] z identifica la zona assegnata all'animale
Animale::Animale(Zona z){
    zona = z;
    nato++;
}

//! \return void \fn Nasce
void Animale::Nasce() {
        cout << "animale nato\n";
    }

//! \return void \fn Mangia
void Animale::Mangia() {
        cout << "ha mangiato\n";
    }

//! \return void \fn EmetteVerso
void Animale::EmetteVerso() {
        cout << "verso\n";
    }

//! \return void \fn CambiaZona \param[in] z identifica la zona in cui l'animale deve essere spostato
void Animale::CambiaZona(Zona z) {
        cout << "zona cambiata da " << zona.GetNome() << "a";
        zona = z;
        cout << zona.GetNome();
    }

//! \return void \fn Morte
void Animale::Morte() {
        cout << "animale morto\n";
        nato--;
        cout << "animali rimasti " << nato << "\n";
    }
