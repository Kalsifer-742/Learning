#ifndef CONTACT_HPP
#define CONTACT_HPP

#include "user.hpp"
#include <string>

using namespace std;

class contact : public user {
    public:
        contact();
        contact(string);
        contact(string, string);
        void set_name(string);
        void set_number(string);
        string get_name();
        string get_number();
    private:
        string number;
};

#endif