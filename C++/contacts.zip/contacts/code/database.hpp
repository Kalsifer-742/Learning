#ifndef DATABASE_HPP
#define DATABASE_HPP

#include "contact.hpp"
#include <string>
using namespace std;

class database {
    public:
        database();
        database(string);
        void read();
        void write(contact&);
        bool search(contact&);
        bool cancel(contact&);
    private:
        string path;
};

#endif