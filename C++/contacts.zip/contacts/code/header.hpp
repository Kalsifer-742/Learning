#ifndef HEADER_HPP
#define HEADER_HPP

#include <string>
#include <exception>
#include <iostream>
#include <fstream>
#include <sstream>

#include "user.hpp"
#include "contact.hpp"
#include "database.hpp"

#endif