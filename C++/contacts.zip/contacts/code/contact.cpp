#include "header.hpp"

using namespace std;

contact::contact() { username = ""; number = ""; }
contact::contact(string u) : user(u) {}
contact::contact(string u, string n) : user(u){
    number = n;
}

void contact::set_name(string u) { username = u; }
void contact::set_number(string n) { number = n; }
string contact::get_name() { return username; }
string contact::get_number() { return number; }