#include "header.hpp"
#include <unistd.h>

using namespace std;

database::database() { path = "unknown"; }
inline bool file_exists(const std::string&);
database::database(string p) {
  if(file_exists(p)){
    cout << endl << "SUCCESS >>> found an existing database with this name" << endl;
  }
  else{
    cout << endl << "WARNING >>> non existing database. creating a new one" << endl;
  }
  path = p;
}

//source: https://stackoverflow.com/questions/12774207/fastest-way-to-check-if-a-file-exist-using-standard-c-c11-c
inline bool file_exists(const std::string& name){
    return ( access( name.c_str(), F_OK ) != -1 );
}

void database::read(){
    string tmp;
    contact tmp_contact;
    ifstream reader;
    try{
      reader.exceptions(ifstream::failbit | ifstream::badbit | ifstream::eofbit);
      reader.open(path, ios::in);
      while(!reader.eof())
      {
          reader >> tmp;
          stringstream s(tmp);
          getline(s, tmp, ';');
          tmp_contact.set_name(tmp);
          getline(s, tmp);
          tmp_contact.set_number(tmp);
          cout << "NOME: " << tmp_contact.get_name() << " NUMERO: " << tmp_contact.get_number() << endl;
      }
      reader.close();
    }
    catch(ifstream::failure &ex){
      cerr << endl << "Exception occurred while trying to work on the file >>> " << ex.what() << endl;
      return;
    }
    catch (...) {
      cerr << endl << "Default exception occurred" << endl;
      return;
    }
}

void database::write(contact &input){
  ofstream writer;
  try{
    writer.exceptions(ifstream::failbit | ifstream::badbit | ifstream::eofbit);
    writer.open(path, ios::app);
    writer << endl << input.get_name() << ";" << input.get_number();
    writer.close();
  }
  catch(ofstream::failure &ex){
    cerr << endl << "Exception occurred while trying to work on the file >>> " << ex.what() << endl;
    return;
  }
  catch(...){
    cerr << endl << "Default exception occurred" << endl;
    return;
  }
}

bool database::search(contact &input){ //assumo non ci siano duplicati
  string tmp;
  contact tmp_contact;
  ifstream reader;
  bool found = false;
  try{
    reader.exceptions(ifstream::failbit | ifstream::badbit | ifstream::eofbit);
    reader.open(path, ios::in);
    while(!reader.eof())
    {
        reader >> tmp;
        stringstream s(tmp);
        getline(s, tmp, ';');
        tmp_contact.set_name(tmp);
        if(tmp_contact.get_name() == input.get_name())
        {
          found = true;
          cout << tmp_contact.get_number() << endl;
          break;
        }
    }
    reader.close();
    return found;
  }
  catch(ifstream::failure &ex){
    cerr << endl << "Exception occurred while trying to work on the file >>> " << ex.what() << endl;
    return false;
  }
  catch(...){
    cerr << endl << "Default exception occurred" << endl;
    return false;
  }
}

bool database::cancel(contact &input){
    if(!this->search(input))
    {
      return false;
    }
    string tmp, tmp_original;
    ifstream reader;
    ofstream temp;
    try{
      reader.exceptions(ifstream::failbit | ifstream::badbit | ifstream::eofbit);
      reader.open(path, ios::in);
      temp.exceptions(ifstream::failbit | ifstream::badbit | ifstream::eofbit);
      temp.open("temp.txt", ios::out);
      while(getline(reader, tmp))
      {
        reader >> tmp;
        tmp_original = tmp;
        stringstream s(tmp);
        getline(s, tmp, ';');
        if(tmp != input.get_name())
        {
          temp << endl << tmp_original;
        }

      }
      temp.close();
      reader.close();
      remove(path.c_str());
      rename("temp.txt",path.c_str());
      return true;
    }
    catch(ifstream::failure &ex){
      cerr << endl << "Exception occurred while trying to work on the file >>> " << ex.what() << endl;
      return false;
    }
    catch(ofstream::failure &ex){
      cerr << endl << "Exception occurred while trying to work on the file >>> " << ex.what() << endl;
      return false;
    }
    catch(...){
      cerr << endl << "Default exception occurred" << endl;
      return false;
    }
}