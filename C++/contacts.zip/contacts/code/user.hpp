#ifndef USER_HPP
#define USER_HPP

#include <string>
using namespace std;

class user {
    public:
        user();
        user(string );        
    protected:
        string username;
};

#endif