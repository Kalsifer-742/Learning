#include "header.hpp"

using namespace std;

user::user() { username = ""; }

user::user(string u) {
    username = u;
}