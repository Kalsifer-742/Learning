#include "header.hpp"

using namespace std;

//to do: sistemare try catch del menú che non sembra funzionare, capire perché partono eccezzioni nonostante il codice funzioni, criptare database

int main()
{
  database database("database.txt");
  enum selection { exit, lettura, scrittura, ricerca, cancellazione } ;
  int control = -1;
  do{
    cout << "\n1-lettura\n2-scrittura\n3-ricerca\n4-cancellazione\n0-exit\n";
    cin >> control;
    cout << endl;
    try{
      switch (control) {
          case lettura:
            database.read();
            cout << "done" << endl;
            break;
          case scrittura:
          //ho scoperto in modo empirico ancora l'anno scorso che per risolvere basta mettere le graffe all'interno di un case
          //ma perché certe istruzioni danno errore ? (es: assegnazione)
            {
              string name, number;
              cout << "inserire nel seguente formato: <nome> <numero> ";
              cin >> name >> number;
              contact new_contact(name, number);
              database.write(new_contact);
              cout << "done" << endl;
              break;
            }
          case ricerca:
            {
              string name;
              cout << "inserire nel seguente formato: <nome> ";
              cin >> name;
              contact to_search_contact(name);
              if(database.search(to_search_contact))
              {
                cout << "done" << endl;
              }
              else
              {
                cout << "user not found" << endl;
              }
              break;
            }
          case cancellazione:
            {
              string name;
              cout << "inserire nel seguente formato: <nome> ";
              cin >> name;
              contact to_cancel_contact(name);
              if(database.cancel(to_cancel_contact))
              {
                cout << "done" << endl;
              } 
              else 
              {
                cout << "user not found" << endl;
              }
              break;
            }
          case exit:
            break;
          default:
            cout << "unknown command, try again" << endl << endl;
            break;
      }
    }
    catch(...){
      cerr << endl << "Pleanse insert only numbers" << endl;
      continue;
    }
  }while(control != exit);

  return 0;
}