#include <iostream>
#include <fstream>
#include <string>
#include <thread>

using namespace std;

void read()
{
    ifstream input;
    input.open("data.txt", ios::in);
    string tmp;
    while(!input.eof())
    {
        input >> tmp;
        cout << tmp << endl;
    }
    input.close();
}

int main()
{
    thread t1{read};
    thread t2{read};
    t1.join();
    t2.join();

    return 0;
}