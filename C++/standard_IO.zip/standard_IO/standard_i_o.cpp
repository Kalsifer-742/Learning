#include <cstdio>
#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{

    unsigned long long int a;
    signed long long int b;
    long double c;
    char d[10];
    wchar_t e[10];
    char scacchiera [8][8];

    //C++
    cin >> a >> b >> c;
    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
    cin.ignore(256, '\n');
    cin.getline(d, 10, '\n');
    cout << d << endl;
    wcin.ignore(256, '\n'); //non riesco a leggere la stringa
    wcin.getline(e, 10 , '\n');
    cout << e << endl;

    for(int r = 0; r < 8; r++)
    {
        for (int l = 0; l < 8; l++) 
        {
            cin >> scacchiera[r][l];
        }
    }

    for(int r = 0; r < 8; r++)
    {
        for(int l = 0; l < 8; l++)
        {
            cout << scacchiera[r][l] << " ";
        }
        cout << endl;
    }
    cout << endl;

    //C
    scanf("%llu", &a);
    scanf("%lld", &b);
    scanf("%Lf", &c);
    printf("%llu\n" , a);
    printf("%lld\n", a);
    printf("%Lf\n", c);
    scanf("%s*10", d); //anche scrivendo solo %s funziona, come mai ?
    printf("%s\n", d);
    //non riesco a leggere la stringa
    wscanf(L"%ls*10", e); //perché L grande davanti ?
    wprintf(L"%ls\n", e);

    for(int r = 0; r < 8; r++)
    {
        for (int l = 0; l < 8; l++) 
        {
            scanf("%c", &scacchiera[r][l]);
        }
    }

    for(int r = 0; r < 8; r++)
    {
        for(int l = 0; l < 8; l++)
        {
            printf("%c", scacchiera[r][l]); //termina dopo 32, perché ?
        }
        printf("%c", '\n'); //va a capo alla fine di ogni cella e non ogni 8, perché ?
    }
    printf("%c", '\n');

    return 0;
}
