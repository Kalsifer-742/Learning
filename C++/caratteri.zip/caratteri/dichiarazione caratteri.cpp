#include <iostream> 

using namespace std;

int main()
{
    //fonte emoji https://unicode.org/emoji/charts/full-emoji-list.html

    char ascii_string[] = u8"Ci@o#àè😷Ω";

    wchar_t unicode_string[] = L"Ci@o#🦠😷📺🏐Ω";

    cout << "char len: " << sizeof(char)*8 << endl; //8
    cout << "wchar_t len: " << sizeof(wchar_t) * 8 << endl; //32

    cout << ascii_string << " len: " << sizeof(ascii_string)*8 << endl; //128 mi aspettevo 80 dato che ogni carattere é un byte(8bit) ed i carateri sono 9 + 1 carattere fine stringa
    cout << unicode_string << " len: " << sizeof(unicode_string)*8 << endl; //352 dato che ogni carattere sono 4 byte(32bit) ed i caratteri sono 10 + 1 carattere fine stringa
    
    //la differenza di dimensione é giustificata dal diverso quntitativo di bit utilizzati per rappresentare un carattere

    return 0;
}