#include <iostream>
#include <cstring>
using namespace std;

int func_compare_sensitive(char a, char b)
{
    if(a > b)
    {
        return 1;
    }
    else if(a == b)
    {
        return 0;
    }
    return -1;
}
int func_compare_insensitive(char a, char b)
{
    if(a < 97)
    {
        a += 32;
    }
    if(b < 97)
    {
        b += 32;
    }

    if(a > b)
    {
        return 1;
    }
    else if(a == b)
    {
        return 0;
    }
    return -1;
}

void func_compare_characters(char characters[], int (*compare )(char, char))
{
    int len = strlen(characters);

    bool swap = true;
    
    while (swap)
    {
        swap = false;
        for (int i = 0; i < len - 1; i++)
        {
            if(compare(characters[i], characters[i+1]) == 1)
            {
                char tmp = characters[i];
                characters[i] = characters[i+1];
                characters[i+1] = tmp;
                swap = true;
            }
        }
    }
}

int main(){

    char string[] = {"ciao"};

    func_compare_characters(string, func_compare_sensitive);

    cout << string << endl;

    return 0;
}

