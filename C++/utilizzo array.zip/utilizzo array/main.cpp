#include <iostream>
#include <math.h>

using namespace std;

int fattoriale(int n) //https://en.wikipedia.org/wiki/Factorial
{
    int total = 1;
    for(int i = 1; i <= n; i++)
    {
        total *= i;
    }
    return total;
}

int coefficiente(int n, int k) //https://www.youmath.it/domande-a-risposte/view/6207-triangolo-di-tartaglia.html
{
    n--; k--;
    return fattoriale(n) / ( fattoriale(k) * fattoriale(n - k) );
}

int main()
{
    /*int size;
    cin >> size;
    char input[size];
    for(int i = 0; i < size; i++)
        cin >> input[i];

    bool pal = true;
    for(int i = 0; i < size/2; i++)
    {
        if(input[i] != input[(size-1)-i])
        {
            pal = false;
            break;
        }
    }
    cout << pal << endl;*/

    int x, y, n;
    string answer = "G";

    cout << "sviluppo binomio generico o specifico ? [G/s] ";
    cin >> answer; 

    if(answer == "s")
    {
        cout << "(x + y)^n  inserire: x y n --> ";
        cin >> x >> y >> n;
        for (int i = 1, j = 0; i <= (n + 1); i++, j++) {
        cout << coefficiente(n + 1/*riga*/, i/*indice*/) << "*" << x << "^" << (n - j) << "*" << y << "^" << j << " ";
        }

        cout << endl;

        for (int i = 1, j = 0; i <= (n + 1); i++, j++) {
        cout << coefficiente(n + 1/*riga*/, i/*indice*/) * pow ( x, (n - j) ) * pow( y, j ) << " ";
        }
    }
    else
    {
        cout << "(x + y)^n  inserire: n --> ";
        cin >> n;
        for (int i = 1, j = 0; i <= (n + 1); i++, j++) {
            cout << coefficiente(n + 1/*riga*/, i/*indice*/) << "x^"<< (n - j) <<  "y^" << j << " ";
        }
    }

    cout << endl;

    return 0;
}
